import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env file from project root
env_path = Path(__file__).resolve().parent.parent / ".env"
load_dotenv(dotenv_path=env_path)

class Settings:
    OPENCHARGEMAP_API_KEY: str = os.getenv("OPENCHARGEMAP_API_KEY", "").strip()
    OPENROUTESERVICE_API_KEY: str = (
        os.getenv("OPENROUTESERVICE_API_KEY", "").strip() or 
        os.getenv("HEIGIT_API_KEY", "").strip()
    )
    APP_HOST: str = os.getenv("APP_HOST", "127.0.0.1").strip()
    APP_PORT: int = int(os.getenv("APP_PORT", "8085").strip())
    USER_AGENT: str = "EV-Placement-DAA-Academic/1.0 (contact: student@academic.edu)"

settings = Settings()

