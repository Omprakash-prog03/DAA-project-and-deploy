from pydantic import BaseModel, Field
from typing import List, Tuple, Optional

class Coordinates(BaseModel):
    lat: float
    lon: float

class GeocodeResult(BaseModel):
    query: str
    display_name: str
    latitude: float
    longitude: float
    bounding_box: Optional[List[float]] = None
    data_source: str = "OpenStreetMap Nominatim"

class RouteRequest(BaseModel):
    start_lat: float
    start_lon: float
    end_lat: float
    end_lon: float
    start_name: Optional[str] = "Origin"
    end_name: Optional[str] = "Destination"

class RouteResponse(BaseModel):
    distance_km: float
    duration_min: float
    geometry_geojson: Optional[List[List[float]]] = None  # [[lon, lat], ...]
    data_source: str = "OpenStreetMap OSRM / OpenRouteService"

class DistanceMatrixRequest(BaseModel):
    locations: List[Coordinates]

class DistanceMatrixResponse(BaseModel):
    distances_km: List[List[float]]
    durations_min: List[List[float]]
    data_source: str

