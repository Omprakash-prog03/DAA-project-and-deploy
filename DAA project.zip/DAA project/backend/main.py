import os
from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from backend.config import settings
from backend.api import (
    geocode_router,
    stations_router,
    routing_router,
    optimization_router,
)

app = FastAPI(
    title="EV Charging Station Placement & Route Planning",
    description="Real Geographic Data + Hand-Written DAA Algorithms (Kruskal, Dijkstra, 0/1 Knapsack)",
    version="2.0.0"
)

# Enable CORS for local development and browser fetch requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register API Routers
app.include_router(geocode_router)
app.include_router(stations_router)
app.include_router(routing_router)
app.include_router(optimization_router)

@app.get("/api/health", tags=["Health"])
def health_check():
    """Returns real API connectivity and environment configuration status."""
    return {
        "status": "healthy",
        "openchargemap_key_configured": bool(settings.OPENCHARGEMAP_API_KEY),
        "openrouteservice_key_configured": bool(settings.OPENROUTESERVICE_API_KEY),
        "routing_engine": "OpenRouteService" if settings.OPENROUTESERVICE_API_KEY else "OpenStreetMap OSRM",
        "algorithms": [
            "Kruskal's Minimum Spanning Tree (Hand-written)",
            "Dijkstra's Shortest Path (Hand-written)",
            "0/1 Knapsack Dynamic Programming (Hand-written)"
        ]
    }

# Mount Frontend Static Directory
frontend_dir = Path(__file__).resolve().parent.parent / "frontend"
if frontend_dir.exists():
    app.mount("/static", StaticFiles(directory=frontend_dir), name="static")

    @app.get("/")
    async def serve_index():
        return FileResponse(frontend_dir / "index.html")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "backend.main:app",
        host=settings.APP_HOST,
        port=settings.APP_PORT,
        reload=False
    )

