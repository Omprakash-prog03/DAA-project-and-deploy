from fastapi import APIRouter, Query
from backend.models.route import GeocodeResult
from backend.services.geocoding_service import geocode_location

router = APIRouter(prefix="/api/geocode", tags=["Geocoding"])

@router.get("", response_model=GeocodeResult)
def geocode_endpoint(q: str = Query(..., min_length=2, description="City or location query")):
    """Geocodes a geographic address or city into real latitude and longitude."""
    return geocode_location(q)

