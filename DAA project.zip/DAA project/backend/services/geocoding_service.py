import requests
from typing import Optional, Dict
from fastapi import HTTPException
from backend.config import settings
from backend.models.route import GeocodeResult

# In-memory LRU cache to avoid excessive external requests
_geocode_cache: Dict[str, GeocodeResult] = {}

def geocode_location(query: str) -> GeocodeResult:
    """
    Geocodes a location query (e.g. 'Bhubaneswar', 'Delhi', 'New York')
    using real OpenStreetMap Nominatim or OpenRouteService geocoding.
    """
    clean_query = query.strip()
    if not clean_query:
        raise HTTPException(status_code=400, detail="Search query cannot be empty.")

    cache_key = clean_query.lower()
    if cache_key in _geocode_cache:
        return _geocode_cache[cache_key]

    # 1. Try OpenRouteService if API key configured
    if settings.OPENROUTESERVICE_API_KEY:
        try:
            ors_url = "https://api.openrouteservice.org/geocode/search"
            headers = {
                "Authorization": settings.OPENROUTESERVICE_API_KEY,
                "User-Agent": settings.USER_AGENT
            }
            params = {"text": clean_query, "size": 1}
            r = requests.get(ors_url, params=params, headers=headers, timeout=6)
            if r.status_code == 200:
                data = r.json()
                features = data.get("features", [])
                if features:
                    feat = features[0]
                    coords = feat.get("geometry", {}).get("coordinates", [])
                    label = feat.get("properties", {}).get("label", clean_query)
                    if len(coords) >= 2:
                        res = GeocodeResult(
                            query=clean_query,
                            display_name=label,
                            latitude=float(coords[1]),
                            longitude=float(coords[0]),
                            data_source="HeiGIT / OpenRouteService Geocoding"
                        )
                        _geocode_cache[cache_key] = res
                        return res
        except Exception:
            pass  # Fallback to Nominatim

    # 2. OpenStreetMap Nominatim (Standard OpenStreetMap Geocoder)
    try:
        nom_url = "https://nominatim.openstreetmap.org/search"
        headers = {
            "User-Agent": settings.USER_AGENT,
            "Accept": "application/json"
        }
        params = {
            "q": clean_query,
            "format": "json",
            "limit": 1,
            "addressdetails": 1
        }
        resp = requests.get(nom_url, params=params, headers=headers, timeout=8)
        
        if resp.status_code != 200:
            raise HTTPException(
                status_code=502,
                detail=f"Geocoding service returned HTTP {resp.status_code}."
            )

        data = resp.json()
        if not data:
            raise HTTPException(
                status_code=404,
                detail=f"No geographic location found for query '{clean_query}'. Please verify spelling or try a nearby city."
            )

        item = data[0]
        bbox = [float(b) for b in item.get("boundingbox", [])] if "boundingbox" in item else None
        
        result = GeocodeResult(
            query=clean_query,
            display_name=item.get("display_name", clean_query),
            latitude=float(item["lat"]),
            longitude=float(item["lon"]),
            bounding_box=bbox,
            data_source="OpenStreetMap Nominatim"
        )
        _geocode_cache[cache_key] = result
        return result

    except requests.exceptions.Timeout:
        raise HTTPException(
            status_code=504,
            detail="Geocoding request timed out. Please check your internet connection and try again."
        )
    except requests.exceptions.RequestException as e:
        raise HTTPException(
            status_code=503,
            detail=f"Network error communicating with geocoding provider: {str(e)}"
        )

